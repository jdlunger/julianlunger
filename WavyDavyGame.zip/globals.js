const maxExplodedTime = 20;
const sizes = {
  shark: 100,
  sailboat: 200,
  ship: 500,
  wave: 100
};
const types = ['shark', 'sailboat', 'ship', 'wave'];
